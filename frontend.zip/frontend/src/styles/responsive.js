export const res = {
  tablet: '(max-width: 1299px)',
  mobile: '(max-width: 767px)',
};
